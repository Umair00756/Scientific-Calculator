
package calculator;


public class Calculator {

   
    public static void main(String[] args) {
        Calculate calculate = new Calculate();
         calculate.setVisible(true);
         calculate.pack();
         calculate.setLocationRelativeTo(null);
    }
    
}
