package calculator;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;

public class Button extends JButton {

    private Color color;
    private Color colorHover;
    private boolean isHovered;
    private int radius = 20; // Example radius for rounded corners

    public Button() {
        // Initialize the button color and hover color
        color = new Color(192, 113, 46); // Original color
        colorHover = color.brighter();   // Brighter version of the original color
//align


        setHorizontalAlignment(CENTER);
        setVerticalAlignment(CENTER);

        // Set the button to be transparent
        setContentAreaFilled(false);

        // Add a mouse listener to handle hover effects
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                isHovered = true;
                repaint(); // Repaint the button to show the hover effect
            }

            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                repaint(); // Repaint the button to remove the hover effect
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Choose the color based on whether the button is hovered or not
        if (isHovered) {
            g2.setColor(colorHover);
        } else {
            g2.setColor(color);
        }
//        shadow
            
        // Draw the button with rounded corners
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);

        super.paintComponent(g);
    }

    // Getter and Setter for Radius
    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
        repaint();
    }
}



